﻿Public Class mainmenu

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim game As New Form1
        AddHandler game.FormClosed, AddressOf OnGameClosed
        game.Show()
        Hide()
    End Sub
    Private Sub OnGameClosed(sender As Object, e As FormClosedEventArgs)
        Application.Exit()
    End Sub


    Private Sub btnQuit_Click(sender As Object, e As EventArgs) Handles btnQuit.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnH2P.Click
        MessageBox.Show("Use the arrow keys to move and rotate the pieces. Fill up horizontal lines to clear them and score points. The game ends when the pieces stack up to the top of the playing field. Good luck!", "How to Play")
    End Sub
End Class