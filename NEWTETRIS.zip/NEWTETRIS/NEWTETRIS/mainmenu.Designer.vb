﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class mainmenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        btnStart = New Button()
        btnQuit = New Button()
        btnH2P = New Button()
        SuspendLayout()
        ' 
        ' btnStart
        ' 
        btnStart.Font = New Font("Consolas", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnStart.Location = New Point(280, 159)
        btnStart.Name = "btnStart"
        btnStart.Size = New Size(241, 69)
        btnStart.TabIndex = 0
        btnStart.Text = "START"
        btnStart.UseVisualStyleBackColor = True
        ' 
        ' btnQuit
        ' 
        btnQuit.Font = New Font("Consolas", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnQuit.Location = New Point(280, 335)
        btnQuit.Name = "btnQuit"
        btnQuit.Size = New Size(241, 69)
        btnQuit.TabIndex = 1
        btnQuit.Text = "EXIT GAME"
        btnQuit.UseVisualStyleBackColor = True
        ' 
        ' btnH2P
        ' 
        btnH2P.Font = New Font("Consolas", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnH2P.Location = New Point(280, 245)
        btnH2P.Name = "btnH2P"
        btnH2P.Size = New Size(241, 69)
        btnH2P.TabIndex = 2
        btnH2P.Text = "HOW TO PLAY"
        btnH2P.UseVisualStyleBackColor = True
        ' 
        ' mainmenu
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = My.Resources.Resources.BRICKED_UP__1_
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(800, 450)
        Controls.Add(btnH2P)
        Controls.Add(btnQuit)
        Controls.Add(btnStart)
        Name = "mainmenu"
        Text = "mainmenu"
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnStart As Button
    Friend WithEvents btnQuit As Button
    Friend WithEvents btnH2P As Button
End Class
