﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        picBoard = New PictureBox()
        picNext = New PictureBox()
        lblScore = New Label()
        Label1 = New Label()
        fallTimer = New Timer(components)
        CType(picBoard, ComponentModel.ISupportInitialize).BeginInit()
        CType(picNext, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' picBoard
        ' 
        picBoard.BorderStyle = BorderStyle.Fixed3D
        picBoard.Location = New Point(75, 26)
        picBoard.Name = "picBoard"
        picBoard.Size = New Size(300, 600)
        picBoard.TabIndex = 0
        picBoard.TabStop = False
        ' 
        ' picNext
        ' 
        picNext.BackColor = Color.Transparent
        picNext.Location = New Point(465, 301)
        picNext.Name = "picNext"
        picNext.Size = New Size(120, 120)
        picNext.TabIndex = 1
        picNext.TabStop = False
        ' 
        ' lblScore
        ' 
        lblScore.AutoSize = True
        lblScore.Font = New Font("Consolas", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblScore.Location = New Point(465, 103)
        lblScore.Name = "lblScore"
        lblScore.Size = New Size(90, 27)
        lblScore.TabIndex = 2
        lblScore.Text = "Score:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Consolas", 13.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(465, 254)
        Label1.Name = "Label1"
        Label1.Size = New Size(90, 27)
        Label1.TabIndex = 3
        Label1.Text = " Next:"
        ' 
        ' fallTimer
        ' 
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(637, 953)
        Controls.Add(Label1)
        Controls.Add(lblScore)
        Controls.Add(picNext)
        Controls.Add(picBoard)
        Name = "Form1"
        Text = "Form1"
        CType(picBoard, ComponentModel.ISupportInitialize).EndInit()
        CType(picNext, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents picBoard As PictureBox
    Friend WithEvents picNext As PictureBox
    Friend WithEvents lblScore As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents fallTimer As Timer

End Class
